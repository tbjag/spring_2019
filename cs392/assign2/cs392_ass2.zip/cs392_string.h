//cs392_string.h
//Theodore Jagodits CS392 HW 2
//"I pledge my honor that I have abided by the Stevens Honor System"

#ifndef CS392_STRING
#define CS392_STRING

void * cs392_memcpy ( void * dst, void * src, unsigned num);
unsigned cs392_strlen(char *str);

#endif