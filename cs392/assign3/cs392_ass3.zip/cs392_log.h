/*
*   Theodore Jagodits
*   CS 392
*   cs392_shell.c
*   I pledge my honor that I have abided by the Stevens Honor System
*/

#ifndef CS392_LOG_H
#define CS392_LOG_H

#include<stdio.h>

void logtolog(char*);

#endif