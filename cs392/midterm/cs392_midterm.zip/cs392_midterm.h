//“I pledge my honor that I have abided by the Stevens Honor System.”
//Theodore Jagodits 
// CS 392 Midterm
#ifndef CS392_MIDTERM
#define CS392_MIDTERM

char *cs392_strcpy(char *dest, char *src);
int cs392_strcmp(char *s1, char *s2);
char *cs392_strncat(char *dest, char *src, unsigned n);

#endif